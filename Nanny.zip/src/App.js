import './App.css';
import Navbar from './Components/Navbar';
import Order_placed from './Components/All_Parents';

import Parent_t_Child from './Components/Parent_t_Child';

function App() {
  

  return (
    <div className='App'>
      <Navbar/>
      {/* <Order_placed/> */}
      <Parent_t_Child/>
   
 

    </div>
  );
}

export default App;
