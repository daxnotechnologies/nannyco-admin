import React from 'react'

import Vector from '../assets/sort.png';
import Vector1 from '../assets/Filter.png';
import ChildDisplay from './ChildDisplay';

function AllChilds
    () {

    const Children = [
        {
            id: 1,
            pid: 1,
            name: 'Jason Crejza',
            age:'2 years 5 months',
            img: '1',



        },
        {
            id: 2,
            pid: 1,
            name: 'Emily Watson',

            img: '5',



        },
        {
            id: 3,
            pid: 2,
            name: 'Sarah Taylor',

            img: '6',


        },
        {
            id: 4,
            pid: 2,
            name: 'Jeff Kim ',

            img: '2',


        },
        {
            id: 5,
            pid: 3,
            name: 'Steve Shaprio',

            img: '3',


        },
        {
            id: 6,
            pid: 3,
            name: 'Robert Downey',

            img: '4',


        },
    ]
    return (
        <div className='w-[1150px] bg-white rounded-[8px] border-[1px] absolute left-[400px] top-[450px]'>
            <div className='flex'>
                <p className='w-[200px] font-Poppins m-10 text-2xl font-semibold  '>Children</p>
                <div className='flex w-[100%] justify-end mt-10 mr-14 font-Poppins text-[#4B506D] font-medium space-x-5'>
                    <img src={Vector} alt='' className=' w-[17px] h-[14px] mt-[5px] ' />
                    <label>Sort</label>
                    <img src={Vector1} alt='' className=' w-[14px] h-[14px] mt-[5px] ' />
                    <label>Filter</label>
                </div>



            </div>
            <div className='text-[#4B506D] font-Poppins font-medium'>
                <label className='ml-14 absolute '>Name</label>
                <div className='ml-[300px]'>
                    <div className='flex  '>
                        <label className='w-[250px]'>Age</label>
                        <label className='w-[250px]'>Special Child</label>



                    </div>
                </div>
                <hr />
            </div>

            {
                Children.map((val, id) => {

                    const a = val.img
                    // eslint-disable-next-line react/jsx-pascal-case
                    return <ChildDisplay
                        key={id}
                        name={val.name}



                        img={require('./profile/img' + a + '.png')}


                    />
                })
            }



        </div>
    )
}

export default AllChilds
