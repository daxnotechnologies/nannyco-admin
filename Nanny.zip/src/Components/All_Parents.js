import React from 'react'

import Vector from '../assets/sort.png';
import Vector1 from '../assets/Filter.png';
import arrow1 from '../assets/arrw1.png';
import arrow2 from '../assets/arrw2.png';

import ParentDisplay from './ParentDisplay';

function AllParents
    () {

    const Parents = [
        {
            id: 1,
            parent: 'Jason Crejza',
            Address: '7485 Second Rd.Powder Springs, GA 30127',
            Phone: '0311-5522663',
            username: 'Danny_123',
            img: '1',



        },
        {
            id: 1,
            parent: 'Emily Watson',
            Address: '7485 Second Rd.Powder Springs, GA 30127',
            Phone: '0311-5522663',
            username: 'Danny_123',
            img: '5',



        },
        {
            id: 1,
            parent: 'Sarah Taylor',
            Address: '7485 Second Rd.Powder Springs, GA 30127',
            Phone: '0311-5522663',
            username: 'Danny_123',
            img: '6',


        },
        {
            id: 1,
            parent: 'Jeff Kim ',
            Address: '7485 Second Rd.Powder Springs, GA 30127',
            Phone: '0311-5522663',
            username: 'Danny_123',
            img: '2',


        },
        {
            id: 1,
            parent: 'Steve Shaprio',
            Address: '7485 Second Rd.Powder Springs, GA 30127',
            Phone: '0311-5522663',
            username: 'Danny_123',
            img: '3',


        },
        {
            id: 1,
            parent: 'Robert Downey',
            Address: '7485 Second Rd.Powder Springs, GA 30127',
            Phone: '0311-5522663',
            username: 'Danny_123',
            img: '4',


        },
    ]
    return (
        <div className='w-[1150px] bg-white rounded-[8px] border-[1px] absolute left-[400px] mt-[10px]'>
            <div className='flex'>
                <p className='w-[200px] font-Poppins m-10 text-2xl font-semibold  '>Parents</p>
                <div className='flex w-[100%] justify-end mt-10 mr-14 font-Poppins text-[#4B506D] font-medium space-x-5'>
                    <img src={Vector} alt='' className=' w-[17px] h-[14px] mt-[5px] ' />
                    <label>Sort</label>
                    <img src={Vector1} alt='' className=' w-[14px] h-[14px] mt-[5px] ' />
                    <label>Filter</label>
                </div>



            </div>
            <div className='text-[#4B506D] font-Poppins font-medium'>
                <label className='ml-14 absolute '>Parents</label>
                <div className='ml-[300px]'>
                    <div className='flex  '>
                        <label className='w-[250px]'>Address</label>
                        <label className='w-[170px]'>Phone</label>
                        <label className='w-[200px]'>UserName</label>

                    </div>
                </div>
                <hr />
            </div>

            {
                Parents.map((val, id) => {

                    const a = val.img
                    // eslint-disable-next-line react/jsx-pascal-case
                    return <ParentDisplay
                        key={id}
                        parent={val.parent}
                        Address={val.Address}

                        Phone={val.Phone}
                        username={val.username}
                        img={require('./profile/img' + a + '.png')}


                    />
                })
            }
            <div className='flex mb-7'>
                <div className='flex justify-end w-[90%] text-[#9FA2B4] space-x-40'>
                    <label>Rows per page 8</label>
                    <label >1-8 of 1240</label>

                </div>
                <img src={arrow1} alt='' className='  ' />
                <img src={arrow2} alt='' className='  ' />
            </div>


        </div>
    )
}

export default AllParents
