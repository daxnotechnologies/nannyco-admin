import './App.css';
import Bcards from './Components/Bcards';
import Header from './Components/Header';
// import Login from './components/Login';
// import Signup from './components/Signup';
// import {
//   BrowserRouter as Router,
//   Routes,
//   Route,
// } from 'react-router-dom';
// import Home from './components/Home';
import Navbar from './Components/Navbar';
import Cardlist from './Components/CardList'
import AdminGraph from './Components/AdminGraph'
import AdminCard from './Components/AdminCard';
import Orders from './Components/Orders';
import Order_display from './Components/Order_display';
import Order_placed from './Components/Order_placed';
import Guide from './Components/Guide'

function App() {
  

  return (
    <div className='App'>
      <div>
<Navbar/> 
</div>
<div>
<Header/>
</div>
{/* <div>
<Cardlist/>
</div>
<div>
<AdminGraph/>
</div>

 <Bcards/>
 <div>
 <Orders/>
    </div>  */}

    {/* <Order_placed/> */}
    {/* <Guide/> */}
    </div>
  );
}

export default App;
